namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SiteExchangeFluent2 : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.SiteOffers", name: "SiteExchange_Id", newName: "SiteExchangeId");
        }
        
        public override void Down()
        {
            RenameColumn(table: "dbo.SiteOffers", name: "SiteExchangeId", newName: "SiteExchange_Id");
        }
    }
}
