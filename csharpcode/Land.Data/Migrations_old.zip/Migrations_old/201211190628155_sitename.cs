namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class sitename : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Sites", "Name", c => c.String(nullable: false));
            DropColumn("dbo.Sites", "SiteName");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Sites", "SiteName", c => c.String());
            DropColumn("dbo.Sites", "Name");
        }
    }
}
