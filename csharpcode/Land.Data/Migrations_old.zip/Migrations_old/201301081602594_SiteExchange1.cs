namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SiteExchange1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.SiteOffers", "Id", "dbo.SiteExchanges");
            DropIndex("dbo.SiteOffers", new[] { "Id" });
            AlterColumn("dbo.SiteOffers", "Id", c => c.Int(nullable: false, identity: true));
            AlterColumn("dbo.SiteExchanges", "Id", c => c.Int(nullable: false));
            AddForeignKey("dbo.SiteExchanges", "Id", "dbo.SiteOffers", "Id");
            CreateIndex("dbo.SiteExchanges", "Id");
        }
        
        public override void Down()
        {
            DropIndex("dbo.SiteExchanges", new[] { "Id" });
            DropForeignKey("dbo.SiteExchanges", "Id", "dbo.SiteOffers");
            AlterColumn("dbo.SiteExchanges", "Id", c => c.Int(nullable: false, identity: true));
            AlterColumn("dbo.SiteOffers", "Id", c => c.Int(nullable: false));
            CreateIndex("dbo.SiteOffers", "Id");
            AddForeignKey("dbo.SiteOffers", "Id", "dbo.SiteExchanges", "Id");
        }
    }
}
