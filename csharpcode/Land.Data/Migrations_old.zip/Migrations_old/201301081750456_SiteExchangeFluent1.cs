namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SiteExchangeFluent1 : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.SiteOffers", "SiteExchangeId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.SiteOffers", "SiteExchangeId", c => c.Int());
        }
    }
}
