namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Towncrudinfo : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Towns", "ChangedBy");
            DropColumn("dbo.Towns", "CreatedBy");
            DropColumn("dbo.Towns", "Modified");
            DropColumn("dbo.Towns", "Created");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Towns", "Created", c => c.DateTime(nullable: false));
            AddColumn("dbo.Towns", "Modified", c => c.DateTime(nullable: false));
            AddColumn("dbo.Towns", "CreatedBy", c => c.String());
            AddColumn("dbo.Towns", "ChangedBy", c => c.String());
        }
    }
}
