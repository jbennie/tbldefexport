namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class plotchanges : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.SitePlots", "SiteId", "dbo.Sites");
            DropForeignKey("dbo.SitePlots", "LandPlotTypeId", "dbo.LandPlotTypes");
            DropIndex("dbo.SitePlots", new[] { "SiteId" });
            DropIndex("dbo.SitePlots", new[] { "LandPlotTypeId" });
            CreateTable(
                "dbo.Plots",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        SiteId = c.Int(nullable: false),
                        plotcount = c.Int(nullable: false),
                        LandPlotTypeId = c.Int(),
                        IsSocialHousing = c.Boolean(nullable: false),
                        notes = c.String(),
                        reason = c.String(),
                        comment = c.String(),
                        totalareasqm = c.Double(nullable: false),
                        ChangedBy = c.String(),
                        CreatedBy = c.String(),
                        Modified = c.DateTime(nullable: false),
                        Created = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Sites", t => t.SiteId, cascadeDelete: true)
                .ForeignKey("dbo.LandPlotTypes", t => t.LandPlotTypeId)
                .Index(t => t.SiteId)
                .Index(t => t.LandPlotTypeId);
            
            DropTable("dbo.SitePlots");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.SitePlots",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        SiteId = c.Int(nullable: false),
                        PlotCount = c.Int(nullable: false),
                        LandPlotTypeId = c.Int(),
                        IsSocialHousing = c.Boolean(nullable: false),
                        Notes = c.String(),
                        Reason = c.String(),
                        Comment = c.String(),
                        TotalAreaSqm = c.Double(nullable: false),
                        DevelopableAreaSqm = c.Double(nullable: false),
                        ChangedBy = c.String(),
                        CreatedBy = c.String(),
                        Modified = c.DateTime(nullable: false),
                        Created = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            DropIndex("dbo.Plots", new[] { "LandPlotTypeId" });
            DropIndex("dbo.Plots", new[] { "SiteId" });
            DropForeignKey("dbo.Plots", "LandPlotTypeId", "dbo.LandPlotTypes");
            DropForeignKey("dbo.Plots", "SiteId", "dbo.Sites");
            DropTable("dbo.Plots");
            CreateIndex("dbo.SitePlots", "LandPlotTypeId");
            CreateIndex("dbo.SitePlots", "SiteId");
            AddForeignKey("dbo.SitePlots", "LandPlotTypeId", "dbo.LandPlotTypes", "Id");
            AddForeignKey("dbo.SitePlots", "SiteId", "dbo.Sites", "Id", cascadeDelete: true);
        }
    }
}
