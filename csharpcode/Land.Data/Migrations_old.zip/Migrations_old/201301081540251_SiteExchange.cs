namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SiteExchange : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.SiteOffers", name: "OfferDecissionType_Id", newName: "OfferDecissionTypeId");
            CreateTable(
                "dbo.SiteExchanges",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        SaleStartDate = c.DateTime(),
                        AgreedSTCDate = c.DateTime(),
                        ProjectedExchangeDate = c.DateTime(),
                        ProjectedCompletionDate = c.DateTime(),
                        ActualExchangeDate = c.DateTime(),
                        ActualCompletionDate = c.DateTime(),
                        SearchesSumbitedDate = c.DateTime(),
                        PreliminaryEnquiryDate = c.DateTime(),
                        DraftContractSubmittedDate = c.DateTime(),
                        Commission = c.Double(),
                        NettFeePercent = c.Double(),
                        PurchaserId = c.Int(),
                        VendorSolicitorId = c.Int(),
                        PurchaserSolicitorId = c.Int(),
                        BrokerSolicitorId = c.Int(),
                        ProjectedReleaseDate = c.DateTime(),
                        SiteOfferId = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Contacts", t => t.PurchaserId)
                .ForeignKey("dbo.Contacts", t => t.VendorSolicitorId)
                .ForeignKey("dbo.Contacts", t => t.PurchaserSolicitorId)
                .ForeignKey("dbo.Contacts", t => t.BrokerSolicitorId)
                .Index(t => t.PurchaserId)
                .Index(t => t.VendorSolicitorId)
                .Index(t => t.PurchaserSolicitorId)
                .Index(t => t.BrokerSolicitorId);
            
            AddColumn("dbo.Contacts", "IsPurchaser", c => c.Boolean());
            AddColumn("dbo.Contacts", "IsVendorSolicitor", c => c.Boolean());
            AddColumn("dbo.Contacts", "IsPurchaserSolicitor", c => c.Boolean());
            AddColumn("dbo.Contacts", "IsBrokerSolicitor", c => c.Boolean());
            AddColumn("dbo.SiteOffers", "SiteExchangeId", c => c.Int());
            AlterColumn("dbo.SiteOffers", "Id", c => c.Int(nullable: false));
            AddForeignKey("dbo.SiteOffers", "Id", "dbo.SiteExchanges", "Id");
            CreateIndex("dbo.SiteOffers", "Id");
            DropColumn("dbo.SiteOffers", "OfferDecissionId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.SiteOffers", "OfferDecissionId", c => c.Int());
            DropIndex("dbo.SiteExchanges", new[] { "BrokerSolicitorId" });
            DropIndex("dbo.SiteExchanges", new[] { "PurchaserSolicitorId" });
            DropIndex("dbo.SiteExchanges", new[] { "VendorSolicitorId" });
            DropIndex("dbo.SiteExchanges", new[] { "PurchaserId" });
            DropIndex("dbo.SiteOffers", new[] { "Id" });
            DropForeignKey("dbo.SiteExchanges", "BrokerSolicitorId", "dbo.Contacts");
            DropForeignKey("dbo.SiteExchanges", "PurchaserSolicitorId", "dbo.Contacts");
            DropForeignKey("dbo.SiteExchanges", "VendorSolicitorId", "dbo.Contacts");
            DropForeignKey("dbo.SiteExchanges", "PurchaserId", "dbo.Contacts");
            DropForeignKey("dbo.SiteOffers", "Id", "dbo.SiteExchanges");
            AlterColumn("dbo.SiteOffers", "Id", c => c.Int(nullable: false, identity: true));
            DropColumn("dbo.SiteOffers", "SiteExchangeId");
            DropColumn("dbo.Contacts", "IsBrokerSolicitor");
            DropColumn("dbo.Contacts", "IsPurchaserSolicitor");
            DropColumn("dbo.Contacts", "IsVendorSolicitor");
            DropColumn("dbo.Contacts", "IsPurchaser");
            DropTable("dbo.SiteExchanges");
            RenameColumn(table: "dbo.SiteOffers", name: "OfferDecissionTypeId", newName: "OfferDecissionType_Id");
        }
    }
}
