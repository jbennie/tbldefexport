namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SiteExchangeFluent : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.SiteExchanges", "Id", "dbo.SiteOffers");
            DropIndex("dbo.SiteExchanges", new[] { "Id" });
            AddColumn("dbo.SiteOffers", "SiteExchange_Id", c => c.Int());
            AlterColumn("dbo.SiteExchanges", "Id", c => c.Int(nullable: false, identity: true));
            AddForeignKey("dbo.SiteOffers", "SiteExchange_Id", "dbo.SiteExchanges", "Id");
            CreateIndex("dbo.SiteOffers", "SiteExchange_Id");
        }
        
        public override void Down()
        {
            DropIndex("dbo.SiteOffers", new[] { "SiteExchange_Id" });
            DropForeignKey("dbo.SiteOffers", "SiteExchange_Id", "dbo.SiteExchanges");
            AlterColumn("dbo.SiteExchanges", "Id", c => c.Int(nullable: false));
            DropColumn("dbo.SiteOffers", "SiteExchange_Id");
            CreateIndex("dbo.SiteExchanges", "Id");
            AddForeignKey("dbo.SiteExchanges", "Id", "dbo.SiteOffers", "Id");
        }
    }
}
