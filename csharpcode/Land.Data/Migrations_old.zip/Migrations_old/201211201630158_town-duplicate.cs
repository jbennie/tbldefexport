namespace Land.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class townduplicate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Towns", "Duplicate", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Towns", "Duplicate");
        }
    }
}
